<?php

/**
 *
 */
class station
{
  private $name = null;
  private $id   = null;

  function __construct( $_name, $_id )
  {
    $this->name = $_name;
    $this->id   = $_id;
  }
}


 ?>
