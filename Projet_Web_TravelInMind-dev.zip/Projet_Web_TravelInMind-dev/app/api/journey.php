<?php
  /**
   *
   */
  class Journey
  {
    private $date_start     = null;
    private $time_start     = null;
    private $time_stop      = null;
    private $station_start  = null;
    private $station_stop   = null;
    private $sections       = null;



    function __construct()
    {
      # code...
    }
  }

 ?>
