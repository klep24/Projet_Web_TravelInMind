<?php
/**
 *
 */
class Section
{
  private static $id          = 0;

  private $num                = null;
  private $num_train          = null;
  private $type_train         = null;
  private $time_start         = null;
  private $time_stop          = null;
  private $station_start      = null;
  private $station_stop       = null;
  private $station_direction  = null;

  function __construct(argument)
  {
    # code...
  }
}

 ?>
