### Mini-projet Application Web
## Travel In Mind (TIM)

L'objet de notre application est de fournir un assistant pour les voyages s'effectuant en transport en commun, en l'occurrence, nous nous sommes concentrés sur les services fournis par la SNCF.

Au travers de l'utilisation de l'API SNCF, nous avons crées un application permettant aux utilisateurs de rechercher un trajet, s'y abonner et obtenir des informations en temps réel sur ces derniers.

L'application est autonome, multi-plateforme et ergonomique.

- Julie Petitjean
- Charlotte Rambourg
- Bastien Binet
- Kévin Leprêtre 
